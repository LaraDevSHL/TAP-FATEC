package com.fatec.aula.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fatec.aula.entities.Product;

public interface ProductRepository extends JpaRepository<Product, Long>  {

    
}  
    

